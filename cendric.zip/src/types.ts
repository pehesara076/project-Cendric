export type TransactionType = 'income' | 'expense' | 'investment';

export interface Transaction {
  id: string;
  title: string;
  amount: number;
  type: TransactionType;
  category: string;
  date: string; // YYYY-MM-DD
  account: string;
  notes?: string;
  isRecurring?: boolean;
}

export interface BudgetCategory {
  id: string;
  name: string;
  allocated: number;
  spent: number;
  color: string;
  iconName: string;
}

export interface FinancialGoal {
  id: string;
  title: string;
  targetAmount: number;
  currentAmount: number;
  targetDate: string;
  category: 'savings' | 'investment' | 'debt' | 'purchase';
  color: string;
}

export interface RecurringBill {
  id: string;
  name: string;
  amount: number;
  dueDate: number; // day of month (1-31)
  category: string;
  autoPay: boolean;
  status: 'paid' | 'pending' | 'overdue';
}

export interface NetWorthPoint {
  month: string;
  assets: number;
  liabilities: number;
  netWorth: number;
}

export interface AIInsightRequest {
  query?: string;
  transactions: Transaction[];
  budgets: BudgetCategory[];
  goals: FinancialGoal[];
  totalBalance: number;
}

export interface AIInsightResponse {
  summary: string;
  keyActionItems: string[];
  budgetAlerts: string[];
  healthScore: number; // 0 - 100
  savingsRate: number;
}
