import React, { useState } from 'react';
import { PieChart, Plus, AlertCircle, CheckCircle2, TrendingUp, Edit2, Trash2 } from 'lucide-react';
import { BudgetCategory } from '../types';
import { formatCurrency } from '../utils/formatters';

interface BudgetsProps {
  budgets: BudgetCategory[];
  onAddBudget: (category: BudgetCategory) => void;
  onUpdateBudget: (id: string, allocated: number) => void;
  onDeleteBudget: (id: string) => void;
}

export const Budgets: React.FC<BudgetsProps> = ({
  budgets,
  onAddBudget,
  onUpdateBudget,
  onDeleteBudget,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [newAllocated, setNewAllocated] = useState('');
  const [editingBudgetId, setEditingBudgetId] = useState<string | null>(null);
  const [editingAllocated, setEditingAllocated] = useState('');

  const totalAllocated = budgets.reduce((sum, b) => sum + b.allocated, 0);
  const totalSpent = budgets.reduce((sum, b) => sum + b.spent, 0);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCategoryName || !newAllocated) return;

    onAddBudget({
      id: `b-${Date.now()}`,
      name: newCategoryName,
      allocated: parseFloat(newAllocated),
      spent: 0,
      color: '#3b82f6',
      iconName: 'PieChart',
    });

    setNewCategoryName('');
    setNewAllocated('');
    setIsModalOpen(false);
  };

  const handleStartEdit = (b: BudgetCategory) => {
    setEditingBudgetId(b.id);
    setEditingAllocated(b.allocated.toString());
  };

  const handleSaveEdit = (id: string) => {
    if (editingAllocated) {
      onUpdateBudget(id, parseFloat(editingAllocated));
    }
    setEditingBudgetId(null);
  };

  return (
    <div className="space-y-6">
      {/* Top Header Row */}
      <div className="p-5 bg-white border border-slate-200/80 rounded-xl shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center space-x-2">
            <PieChart className="w-5 h-5 text-blue-600" />
            <span>Budget Architecture</span>
          </h1>
          <p className="text-xs text-slate-500">Define category expenditure boundaries and prevent lifestyle creep</p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center space-x-1.5 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs shadow-blue-600/20 transition active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>New Budget Limit</span>
        </button>
      </div>

      {/* Aggregate Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 bg-white border border-slate-200/80 rounded-xl shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Allocated Budget</span>
          <p className="text-2xl font-bold text-slate-900 mt-1">{formatCurrency(totalAllocated)}</p>
        </div>
        <div className="p-4 bg-white border border-slate-200/80 rounded-xl shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Spent to Date</span>
          <p className="text-2xl font-bold text-blue-600 mt-1">{formatCurrency(totalSpent)}</p>
        </div>
        <div className="p-4 bg-white border border-slate-200/80 rounded-xl shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Remaining Buffer</span>
          <p className={`text-2xl font-bold mt-1 ${totalAllocated >= totalSpent ? 'text-emerald-600' : 'text-rose-600'}`}>
            {formatCurrency(totalAllocated - totalSpent)}
          </p>
        </div>
      </div>

      {/* Budget Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {budgets.map((b) => {
          const pct = Math.min(100, Math.round((b.spent / b.allocated) * 100));
          const isOver = b.spent > b.allocated;
          const isCaution = !isOver && pct >= 80;

          return (
            <div key={b.id} className="p-5 bg-white border border-slate-200/80 rounded-xl shadow-xs space-y-4 hover:border-slate-300 transition">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2.5">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: b.color }} />
                  <h3 className="font-bold text-slate-900 text-sm">{b.name}</h3>
                </div>

                <div className="flex items-center space-x-1">
                  {editingBudgetId === b.id ? (
                    <button
                      onClick={() => handleSaveEdit(b.id)}
                      className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200"
                    >
                      Save
                    </button>
                  ) : (
                    <button
                      onClick={() => handleStartEdit(b)}
                      className="p-1 rounded hover:bg-slate-100 text-slate-400 hover:text-blue-600 transition"
                      title="Edit limit"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                  <button
                    onClick={() => onDeleteBudget(b.id)}
                    className="p-1 rounded hover:bg-slate-100 text-slate-400 hover:text-rose-600 transition"
                    title="Delete Category"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Progress Bar & Allocation */}
              <div className="space-y-1.5">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500 font-medium">Spent: {formatCurrency(b.spent)}</span>
                  {editingBudgetId === b.id ? (
                    <div className="flex items-center space-x-1">
                      <span className="text-slate-500">$</span>
                      <input
                        type="number"
                        value={editingAllocated}
                        onChange={(e) => setEditingAllocated(e.target.value)}
                        className="w-20 bg-slate-50 border border-slate-300 rounded px-1.5 py-0.5 text-xs text-slate-800"
                      />
                    </div>
                  ) : (
                    <span className="text-slate-800 font-bold">Limit: {formatCurrency(b.allocated)}</span>
                  )}
                </div>

                <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden p-0.5 border border-slate-200/60">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${
                      isOver ? 'bg-rose-500' : isCaution ? 'bg-amber-500' : 'bg-blue-600'
                    }`}
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>

              {/* Status Badge */}
              <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-100">
                <span className="text-slate-500">{pct}% utilized</span>
                {isOver ? (
                  <span className="flex items-center space-x-1 text-rose-700 font-semibold bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                    <AlertCircle className="w-3 h-3 text-rose-600" />
                    <span>Exceeded by {formatCurrency(b.spent - b.allocated)}</span>
                  </span>
                ) : isCaution ? (
                  <span className="flex items-center space-x-1 text-amber-700 font-semibold bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                    <AlertCircle className="w-3 h-3 text-amber-600" />
                    <span>Nearing Limit</span>
                  </span>
                ) : (
                  <span className="flex items-center space-x-1 text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    <span>On Track</span>
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal for adding budget category */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4">
          <div className="bg-white border border-slate-200 rounded-2xl p-6 w-full max-w-md shadow-xl text-slate-900">
            <h2 className="text-lg font-bold text-slate-900 mb-4">Create Budget Limit</h2>
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Category Name</label>
                <input
                  type="text"
                  placeholder="e.g. Subscriptions, Travel"
                  value={newCategoryName}
                  onChange={(e) => setNewCategoryName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs text-slate-800 focus:outline-none focus:border-blue-600 focus:bg-white transition"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Monthly Allocated ($)</label>
                <input
                  type="number"
                  placeholder="e.g. 500"
                  value={newAllocated}
                  onChange={(e) => setNewAllocated(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs text-slate-800 focus:outline-none focus:border-blue-600 focus:bg-white transition"
                  required
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-xs"
                >
                  Save Budget
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
