import React, { useState } from 'react';
import { Target, Plus, ShieldAlert, Sparkles, TrendingUp, CheckCircle, Calendar, DollarSign, Trash2 } from 'lucide-react';
import { FinancialGoal } from '../types';
import { formatCurrency, formatDate } from '../utils/formatters';

interface GoalsProps {
  goals: FinancialGoal[];
  onAddGoal: (goal: FinancialGoal) => void;
  onUpdateGoalContribution: (id: string, newAmount: number) => void;
  onDeleteGoal: (id: string) => void;
}

export const Goals: React.FC<GoalsProps> = ({
  goals,
  onAddGoal,
  onUpdateGoalContribution,
  onDeleteGoal,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [targetAmount, setTargetAmount] = useState('');
  const [currentAmount, setCurrentAmount] = useState('');
  const [targetDate, setTargetDate] = useState('');
  const [category, setCategory] = useState<'savings' | 'investment' | 'debt' | 'purchase'>('savings');

  const [contributionInputs, setContributionInputs] = useState<{ [key: string]: string }>({});

  const handleCreateGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !targetAmount || !targetDate) return;

    onAddGoal({
      id: `g-${Date.now()}`,
      title,
      targetAmount: parseFloat(targetAmount),
      currentAmount: parseFloat(currentAmount || '0'),
      targetDate,
      category,
      color: category === 'savings' ? '#2563eb' : category === 'investment' ? '#0d9488' : '#d97706',
    });

    setTitle('');
    setTargetAmount('');
    setCurrentAmount('');
    setTargetDate('');
    setIsModalOpen(false);
  };

  const handleDeposit = (id: string, current: number) => {
    const depositVal = parseFloat(contributionInputs[id] || '0');
    if (depositVal > 0) {
      onUpdateGoalContribution(id, current + depositVal);
      setContributionInputs((prev) => ({ ...prev, [id]: '' }));
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="p-5 bg-white border border-slate-200/80 rounded-xl shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center space-x-2">
            <Target className="w-5 h-5 text-blue-600" />
            <span>Wealth & Target Milestones</span>
          </h1>
          <p className="text-xs text-slate-500">Track long-term savings goals, debt amortization, and major investments</p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center space-x-1.5 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs shadow-blue-600/20 transition active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>New Target Goal</span>
        </button>
      </div>

      {/* Goal Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {goals.map((g) => {
          const pct = Math.min(100, Math.round((g.currentAmount / g.targetAmount) * 100));
          const remaining = Math.max(0, g.targetAmount - g.currentAmount);

          // Calculate months remaining
          const now = new Date();
          const tDate = new Date(g.targetDate);
          const diffMonths = Math.max(1, (tDate.getFullYear() - now.getFullYear()) * 12 + (tDate.getMonth() - now.getMonth()));
          const requiredMonthly = Math.round(remaining / diffMonths);

          return (
            <div key={g.id} className="p-5 bg-white border border-slate-200/80 rounded-xl shadow-xs flex flex-col justify-between space-y-4 hover:border-slate-300 transition">
              <div>
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200">
                      {g.category}
                    </span>
                    <h3 className="font-bold text-slate-900 text-base mt-1">{g.title}</h3>
                  </div>
                  <button
                    onClick={() => onDeleteGoal(g.id)}
                    className="p-1 rounded text-slate-400 hover:text-rose-600 hover:bg-slate-100 transition"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                {/* Amount Progress */}
                <div className="mt-4 space-y-2">
                  <div className="flex justify-between items-baseline">
                    <span className="text-2xl font-bold text-slate-900">{formatCurrency(g.currentAmount)}</span>
                    <span className="text-xs text-slate-500 font-medium">Goal: {formatCurrency(g.targetAmount)}</span>
                  </div>

                  {/* Progress Bar */}
                  <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden p-0.5 border border-slate-200/80">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-blue-600 to-indigo-600 transition-all duration-500"
                      style={{ width: `${pct}%` }}
                    />
                  </div>

                  <div className="flex justify-between items-center text-xs text-slate-500">
                    <span>{pct}% Completed</span>
                    <span className="flex items-center space-x-1">
                      <Calendar className="w-3 h-3 text-slate-400" />
                      <span>{formatDate(g.targetDate)}</span>
                    </span>
                  </div>
                </div>
              </div>

              {/* Monthly Velocity & Quick Contribution */}
              <div className="pt-3 border-t border-slate-100 space-y-3">
                <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200/80 flex justify-between items-center text-xs">
                  <span className="text-slate-500">Req. Velocity:</span>
                  <span className="font-bold text-blue-600">{formatCurrency(requiredMonthly)} / mo</span>
                </div>

                <div className="flex space-x-2">
                  <input
                    type="number"
                    placeholder="Deposit $"
                    value={contributionInputs[g.id] || ''}
                    onChange={(e) =>
                      setContributionInputs({ ...contributionInputs, [g.id]: e.target.value })
                    }
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-blue-600 focus:bg-white transition"
                  />
                  <button
                    onClick={() => handleDeposit(g.id, g.currentAmount)}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs whitespace-nowrap shadow-xs transition"
                  >
                    + Add
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* New Goal Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4">
          <div className="bg-white border border-slate-200 rounded-2xl p-6 w-full max-w-md shadow-xl text-slate-900 space-y-4">
            <h2 className="text-lg font-bold text-slate-900 mb-4">Create Wealth Goal</h2>
            <form onSubmit={handleCreateGoal} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Goal Title</label>
                <input
                  type="text"
                  placeholder="e.g. House Downpayment, Emergency Reserve"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs text-slate-800 focus:outline-none focus:border-blue-600 focus:bg-white transition"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Target Amount ($)</label>
                  <input
                    type="number"
                    placeholder="e.g. 10000"
                    value={targetAmount}
                    onChange={(e) => setTargetAmount(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs text-slate-800 focus:outline-none focus:border-blue-600 focus:bg-white transition"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Current Saved ($)</label>
                  <input
                    type="number"
                    placeholder="e.g. 2500"
                    value={currentAmount}
                    onChange={(e) => setCurrentAmount(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs text-slate-800 focus:outline-none focus:border-blue-600 focus:bg-white transition"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Target Date</label>
                  <input
                    type="date"
                    value={targetDate}
                    onChange={(e) => setTargetDate(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs text-slate-800 focus:outline-none focus:border-blue-600 focus:bg-white transition"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e: any) => setCategory(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs text-slate-800 focus:outline-none focus:border-blue-600 focus:bg-white transition"
                  >
                    <option value="savings">Savings</option>
                    <option value="investment">Investment</option>
                    <option value="purchase">Purchase</option>
                    <option value="debt">Debt Payoff</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-xs"
                >
                  Save Goal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
