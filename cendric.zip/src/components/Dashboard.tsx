import React from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, CartesianGrid } from 'recharts';
import { TrendingUp, ArrowUpRight, ArrowDownRight, Wallet, ShieldCheck, Sparkles, Plus, ChevronRight, Activity, Clock } from 'lucide-react';
import { Transaction, BudgetCategory, NetWorthPoint } from '../types';
import { formatCurrency, formatDate } from '../utils/formatters';

interface DashboardProps {
  transactions: Transaction[];
  budgets: BudgetCategory[];
  netWorthData: NetWorthPoint[];
  totalBalance: number;
  onOpenAddTransaction: () => void;
  onNavigateTab: (tab: string) => void;
  onRequestAiAudit: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  transactions,
  budgets,
  netWorthData,
  totalBalance,
  onOpenAddTransaction,
  onNavigateTab,
  onRequestAiAudit,
}) => {
  // Calculations
  const totalIncome = transactions
    .filter((t) => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalExpenses = transactions
    .filter((t) => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalInvestments = transactions
    .filter((t) => t.type === 'investment')
    .reduce((sum, t) => sum + t.amount, 0);

  const netSurplus = totalIncome - totalExpenses;
  const savingsRate = totalIncome > 0 ? Math.max(0, Math.round((netSurplus / totalIncome) * 100)) : 0;

  // Monthly breakdown mock for bar chart
  const cashFlowData = [
    { name: 'Income', amount: totalIncome, fill: '#10b981' },
    { name: 'Expenses', amount: totalExpenses, fill: '#ef4444' },
    { name: 'Invested', amount: totalInvestments, fill: '#3b82f6' },
  ];

  const recentTransactions = transactions.slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Top Banner / Hero Metric Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Net Worth Card */}
        <div className="p-5 rounded-xl bg-white border border-slate-200/80 shadow-xs relative overflow-hidden group hover:border-blue-300 transition duration-200">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Total Net Assets</span>
            <div className="p-2 rounded-lg bg-blue-50 text-blue-600 border border-blue-100">
              <Wallet className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-bold text-slate-900 tracking-tight">
            {formatCurrency(totalBalance)}
          </div>
          <div className="mt-2 flex items-center space-x-1 text-xs text-emerald-600 font-medium">
            <ArrowUpRight className="w-4 h-4" />
            <span>+7.2% growth this quarter</span>
          </div>
        </div>

        {/* Monthly Net Surplus */}
        <div className="p-5 rounded-xl bg-white border border-slate-200/80 shadow-xs relative overflow-hidden group hover:border-emerald-300 transition duration-200">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Net Monthly Cashflow</span>
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600 border border-emerald-100">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div className={`text-2xl font-bold tracking-tight ${netSurplus >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
            {formatCurrency(netSurplus)}
          </div>
          <div className="mt-2 flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>Savings Rate</span>
            <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              {savingsRate}%
            </span>
          </div>
        </div>

        {/* Total Income */}
        <div className="p-5 rounded-xl bg-white border border-slate-200/80 shadow-xs relative overflow-hidden group hover:border-blue-300 transition duration-200">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Monthly Inflow</span>
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600 border border-emerald-100">
              <ArrowUpRight className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-bold text-slate-900 tracking-tight">
            {formatCurrency(totalIncome)}
          </div>
          <div className="mt-2 text-xs text-slate-500">
            From {transactions.filter((t) => t.type === 'income').length} active income streams
          </div>
        </div>

        {/* Total Expenses */}
        <div className="p-5 rounded-xl bg-white border border-slate-200/80 shadow-xs relative overflow-hidden group hover:border-rose-300 transition duration-200">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Monthly Outflow</span>
            <div className="p-2 rounded-lg bg-rose-50 text-rose-600 border border-rose-100">
              <ArrowDownRight className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-bold text-slate-900 tracking-tight">
            {formatCurrency(totalExpenses)}
          </div>
          <div className="mt-2 text-xs text-slate-500">
            Budget Burn Rate: {budgets.length > 0 ? `${Math.round((totalExpenses / budgets.reduce((a, b) => a + b.allocated, 0)) * 100)}% of limit` : 'N/A'}
          </div>
        </div>
      </div>

      {/* AI Intelligence Spotlight Bar */}
      <div className="p-4.5 rounded-xl bg-gradient-to-r from-slate-900 via-slate-800 to-blue-950 text-white shadow-md flex flex-col md:flex-row items-center justify-between gap-4 border border-slate-800">
        <div className="flex items-center space-x-3.5">
          <div className="p-2.5 rounded-lg bg-blue-500/20 text-blue-300 border border-blue-400/30">
            <Sparkles className="w-5 h-5 animate-pulse text-blue-400" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              Cendric Financial Intelligence
              <span className="text-[10px] bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded-full border border-blue-400/30 font-medium">
                AI ACTIVE
              </span>
            </h3>
            <p className="text-xs text-slate-300 mt-0.5">
              Your overall savings velocity is up by 12% compared to last month. High-yield cash interest is contributing +$142/mo.
            </p>
          </div>
        </div>

        <button
          onClick={onRequestAiAudit}
          className="whitespace-nowrap px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-medium text-xs shadow-xs flex items-center space-x-1.5 transition active:scale-95"
        >
          <Activity className="w-3.5 h-3.5" />
          <span>Run Financial Audit</span>
        </button>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Net Worth Growth Chart (2 columns) */}
        <div className="lg:col-span-2 p-5 rounded-xl bg-white border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center space-x-2">
                <span>Net Worth Trajectory</span>
                <ShieldCheck className="w-4 h-4 text-blue-600" />
              </h2>
              <p className="text-xs text-slate-500">Assets minus liabilities over time</p>
            </div>
            <div className="text-xs font-semibold px-2.5 py-1 rounded-md bg-blue-50 text-blue-700 border border-blue-200">
              6 Month Growth
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={netWorthData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="netWorthGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563eb" stopOpacity={0.25} />
                    <stop offset="95%" stopColor="#2563eb" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="month" stroke="#94a3b8" tick={{ fontSize: 11 }} />
                <YAxis stroke="#94a3b8" tick={{ fontSize: 11 }} tickFormatter={(v) => `$${v / 1000}k`} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#ffffff', borderColor: '#e2e8f0', borderRadius: '10px', color: '#0f172a', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  formatter={(val: any) => [`$${Number(val).toLocaleString()}`, 'Net Worth']}
                />
                <Area type="monotone" dataKey="netWorth" stroke="#2563eb" strokeWidth={3} fillOpacity={1} fill="url(#netWorthGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Monthly Cashflow Bar Breakdown (1 column) */}
        <div className="p-5 rounded-xl bg-white border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900 mb-1">Monthly Flow Breakdown</h2>
            <p className="text-xs text-slate-500 mb-4">Comparison of current month inflows vs outflows</p>

            <div className="h-48 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={cashFlowData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="name" stroke="#94a3b8" tick={{ fontSize: 11 }} />
                  <YAxis stroke="#94a3b8" tick={{ fontSize: 11 }} tickFormatter={(v) => `$${v / 1000}k`} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#ffffff', borderColor: '#e2e8f0', borderRadius: '10px', color: '#0f172a', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                    formatter={(val: any) => [`$${Number(val).toLocaleString()}`, 'Amount']}
                  />
                  <Bar dataKey="amount" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 grid grid-cols-3 gap-2 text-center text-xs">
            <div>
              <p className="text-slate-500">Inflow</p>
              <p className="font-bold text-emerald-600">{formatCurrency(totalIncome)}</p>
            </div>
            <div>
              <p className="text-slate-500">Outflow</p>
              <p className="font-bold text-rose-600">{formatCurrency(totalExpenses)}</p>
            </div>
            <div>
              <p className="text-slate-500">Invested</p>
              <p className="font-bold text-blue-600">{formatCurrency(totalInvestments)}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Section: Budget Progress Summary & Recent Transactions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Budget Allocation Summary */}
        <div className="p-5 rounded-xl bg-white border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-bold text-slate-900">Budget Categories</h2>
            <button
              onClick={() => onNavigateTab('budgets')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center space-x-1"
            >
              <span>Manage</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3.5">
            {budgets.slice(0, 4).map((b) => {
              const pct = Math.min(100, Math.round((b.spent / b.allocated) * 100));
              const isOver = b.spent > b.allocated;
              return (
                <div key={b.id} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-semibold text-slate-700">{b.name}</span>
                    <span className="text-slate-500 font-mono">
                      {formatCurrency(b.spent)} / <span className="text-slate-400">{formatCurrency(b.allocated)}</span>
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        isOver ? 'bg-rose-500' : pct > 80 ? 'bg-amber-500' : 'bg-blue-600'
                      }`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recent Activity Table (2 columns) */}
        <div className="lg:col-span-2 p-5 rounded-xl bg-white border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4 text-blue-600" />
              <h2 className="text-base font-bold text-slate-900">Recent Transactions</h2>
            </div>
            <div className="flex items-center space-x-3">
              <button
                onClick={onOpenAddTransaction}
                className="text-xs font-semibold text-blue-700 hover:text-blue-800 flex items-center space-x-1 bg-blue-50 px-2.5 py-1 rounded border border-blue-200"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>New</span>
              </button>
              <button
                onClick={() => onNavigateTab('transactions')}
                className="text-xs font-semibold text-slate-500 hover:text-slate-800 flex items-center space-x-1"
              >
                <span>View All</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-semibold border-b border-slate-200/80">
                <tr>
                  <th className="p-3">Title</th>
                  <th className="p-3">Category</th>
                  <th className="p-3">Date</th>
                  <th className="p-3 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {recentTransactions.map((tx) => (
                  <tr key={tx.id} className="hover:bg-slate-50/80 transition">
                    <td className="p-3 font-medium text-slate-900 flex items-center space-x-2">
                      <span className={`w-2 h-2 rounded-full ${
                        tx.type === 'income' ? 'bg-emerald-500' : tx.type === 'investment' ? 'bg-blue-500' : 'bg-slate-400'
                      }`} />
                      <span>{tx.title}</span>
                    </td>
                    <td className="p-3 text-slate-500">{tx.category}</td>
                    <td className="p-3 text-slate-500 whitespace-nowrap">{formatDate(tx.date)}</td>
                    <td className={`p-3 text-right font-bold ${
                      tx.type === 'income' ? 'text-emerald-600' : tx.type === 'investment' ? 'text-blue-600' : 'text-slate-800'
                    }`}>
                      {tx.type === 'income' ? '+' : '-'}{formatCurrency(tx.amount)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
