import React from 'react';
import { LayoutDashboard, Receipt, PieChart, Target, CalendarClock, Bot, Plus, Sparkles } from 'lucide-react';
import logoImg from '../assets/images/cendric_logo_1784717236604.jpg';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenAddTransaction: () => void;
  totalBalance: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenAddTransaction,
  totalBalance,
}) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'transactions', label: 'Transactions', icon: Receipt },
    { id: 'budgets', label: 'Budgets', icon: PieChart },
    { id: 'goals', label: 'Wealth Goals', icon: Target },
    { id: 'bills', label: 'Recurring Bills', icon: CalendarClock },
    { id: 'ai-advisor', label: 'Cendric AI', icon: Bot, highlight: true },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 text-slate-800 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo & Name */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('dashboard')}>
            <div className="relative group">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg blur opacity-20 group-hover:opacity-50 transition duration-200"></div>
              <img
                src={logoImg}
                alt="Cendric Logo"
                className="relative h-10 w-10 object-contain rounded-lg border border-slate-200 bg-white shadow-xs"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <div className="flex items-center space-x-1.5">
                <span className="text-xl font-bold tracking-tight text-slate-900">
                  Cendric
                </span>
                <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200">
                  PRO
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium hidden sm:block">
                Financial Growth Engine
              </p>
            </div>
          </div>

          {/* Desktop Navigation Tabs */}
          <nav className="hidden md:flex items-center space-x-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`nav-tab-${item.id}`}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition-all duration-150 ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-xs shadow-blue-600/20'
                      : item.highlight
                      ? 'text-blue-600 hover:bg-blue-50/80 hover:text-blue-700'
                      : 'text-slate-600 hover:bg-slate-100/80 hover:text-slate-900'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : item.highlight ? 'text-blue-600' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                  {item.highlight && !isActive && (
                    <Sparkles className="w-3 h-3 text-blue-600 animate-pulse" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Section: Balance Badge & Action */}
          <div className="flex items-center space-x-3">
            <div className="hidden lg:flex flex-col items-end px-3 py-1 bg-slate-50 rounded-lg border border-slate-200/80">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">
                Net Portfolio
              </span>
              <span className="text-sm font-bold text-emerald-600">
                ${totalBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </span>
            </div>

            <button
              id="quick-add-tx-btn"
              onClick={onOpenAddTransaction}
              className="flex items-center space-x-1.5 px-3.5 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-xs shadow-blue-600/20 transition-all transform active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">Add Entry</span>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Subnav Row */}
      <div className="md:hidden flex overflow-x-auto px-2 py-2 space-x-1 bg-slate-50 border-t border-slate-200/80 scrollbar-none">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-blue-600 text-white font-semibold'
                  : 'text-slate-600 hover:bg-slate-200/60 hover:text-slate-900'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
