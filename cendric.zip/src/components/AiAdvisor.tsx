import React, { useState, useEffect } from 'react';
import { Bot, Sparkles, Send, Activity, ShieldCheck, AlertCircle, ArrowRight, Lightbulb, RefreshCw, CheckCircle2 } from 'lucide-react';
import { Transaction, BudgetCategory, FinancialGoal, AIInsightResponse } from '../types';

interface AiAdvisorProps {
  transactions: Transaction[];
  budgets: BudgetCategory[];
  goals: FinancialGoal[];
  totalBalance: number;
}

export const AiAdvisor: React.FC<AiAdvisorProps> = ({
  transactions,
  budgets,
  goals,
  totalBalance,
}) => {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [insight, setInsight] = useState<AIInsightResponse | null>(null);

  const presetQueries = [
    'How can I optimize my current budget allocation?',
    'What strategy will get me to my $60k investment goal fastest?',
    'Perform a full risk and cash flow assessment on my accounts.',
    'Is my spending rate sustainable for long-term retirement?',
  ];

  const runAudit = async (customQuery?: string) => {
    setLoading(true);
    try {
      const res = await fetch('/api/ai/financial-advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: customQuery || query,
          transactions,
          budgets,
          goals,
          totalBalance,
        }),
      });

      if (!res.ok) throw new Error('API failed');
      const data: AIInsightResponse = await res.json();
      setInsight(data);
    } catch (err) {
      console.error('AI request error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!insight) {
      runAudit();
    }
  }, []);

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    runAudit(query);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-5 bg-white border border-slate-200/80 rounded-xl shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="p-3 rounded-xl bg-blue-50 text-blue-600 border border-blue-200">
            <Bot className="w-7 h-7" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900 flex items-center space-x-2">
              <span>Cendric AI Wealth Advisor</span>
              <span className="text-[10px] bg-blue-50 text-blue-700 font-semibold px-2 py-0.5 rounded border border-blue-200">
                POWERED BY GEMINI
              </span>
            </h1>
            <p className="text-xs text-slate-500">Continuous intelligent wealth auditing, debt optimization, and financial projections</p>
          </div>
        </div>

        <button
          onClick={() => runAudit()}
          disabled={loading}
          className="flex items-center space-x-2 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs disabled:opacity-50 transition active:scale-95"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Analysis</span>
        </button>
      </div>

      {/* Preset Queries Row */}
      <div className="space-y-2">
        <span className="text-xs font-medium text-slate-500 flex items-center space-x-1">
          <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
          <span>Quick Financial Inquiries:</span>
        </span>
        <div className="flex flex-wrap gap-2">
          {presetQueries.map((pq) => (
            <button
              key={pq}
              onClick={() => {
                setQuery(pq);
                runAudit(pq);
              }}
              className="text-xs bg-white hover:bg-slate-50 text-slate-700 font-medium border border-slate-200/80 shadow-xs rounded-lg px-3 py-1.5 transition text-left"
            >
              {pq}
            </button>
          ))}
        </div>
      </div>

      {/* Query Bar */}
      <form onSubmit={handleFormSubmit} className="relative">
        <input
          type="text"
          placeholder="Ask Cendric AI anything about your money, budgets, or investment targets..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="w-full bg-white border border-slate-200 rounded-xl pl-4 pr-12 py-3 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-600 shadow-xs"
        />
        <button
          type="submit"
          disabled={loading || !query.trim()}
          className="absolute right-2 top-2 p-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white disabled:opacity-40 transition shadow-xs"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>

      {/* Loading Skeleton or AI Output */}
      {loading ? (
        <div className="p-12 bg-white border border-slate-200/80 rounded-xl text-center space-y-4 shadow-xs">
          <Sparkles className="w-8 h-8 text-blue-600 animate-spin mx-auto" />
          <p className="text-xs text-slate-500 font-medium">Synthesizing financial telemetry and portfolio metrics...</p>
        </div>
      ) : insight ? (
        <div className="space-y-6">
          {/* Health Score & Key Executive Summary Card */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Score Badge Card */}
            <div className="p-5 bg-white border border-slate-200/80 rounded-xl shadow-xs flex flex-col justify-center items-center text-center">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
                Financial Health Score
              </span>
              <div className="relative flex items-center justify-center">
                <div className="w-24 h-24 rounded-full border-4 border-slate-100 border-t-blue-600 border-r-blue-500 flex items-center justify-center shadow-inner">
                  <span className="text-3xl font-extrabold text-slate-900">{insight.healthScore}</span>
                </div>
              </div>
              <span className="text-xs font-semibold text-emerald-700 mt-2.5 flex items-center space-x-1 bg-emerald-50 px-2.5 py-0.5 rounded border border-emerald-200">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Optimal State</span>
              </span>
            </div>

            {/* Summary Text Card */}
            <div className="md:col-span-3 p-5 bg-white border border-slate-200/80 rounded-xl shadow-xs space-y-3 flex flex-col justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900 flex items-center space-x-2 mb-2">
                  <Sparkles className="w-4 h-4 text-blue-600" />
                  <span>Executive Advisor Summary</span>
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">{insight.summary}</p>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center space-x-6 text-xs text-slate-500">
                <div>
                  Savings Rate: <span className="font-bold text-emerald-600">{insight.savingsRate}%</span>
                </div>
                <div>
                  Active Accounts: <span className="font-bold text-slate-800">Chase, Vanguard, Marcus</span>
                </div>
              </div>
            </div>
          </div>

          {/* Action Items & Budget Alerts */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Key Action Items */}
            <div className="p-5 bg-white border border-slate-200/80 rounded-xl shadow-xs space-y-3">
              <h3 className="text-sm font-bold text-slate-900 flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Strategic Recommendations</span>
              </h3>
              <ul className="space-y-2">
                {insight.keyActionItems.map((item, idx) => (
                  <li key={idx} className="flex items-start space-x-2.5 text-xs text-slate-700 bg-slate-50/80 p-3 rounded-lg border border-slate-200/80">
                    <ArrowRight className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Budget & Spend Alerts */}
            <div className="p-5 bg-white border border-slate-200/80 rounded-xl shadow-xs space-y-3">
              <h3 className="text-sm font-bold text-slate-900 flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 text-amber-500" />
                <span>Budget & Category Observations</span>
              </h3>
              <ul className="space-y-2">
                {insight.budgetAlerts.map((alert, idx) => (
                  <li key={idx} className="flex items-start space-x-2.5 text-xs text-slate-700 bg-slate-50/80 p-3 rounded-lg border border-slate-200/80">
                    <AlertCircle className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                    <span>{alert}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
};
