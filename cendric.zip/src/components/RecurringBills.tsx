import React, { useState } from 'react';
import { CalendarClock, Plus, CheckCircle2, Clock, AlertTriangle, RefreshCw, Trash2 } from 'lucide-react';
import { RecurringBill } from '../types';
import { formatCurrency } from '../utils/formatters';

interface RecurringBillsProps {
  bills: RecurringBill[];
  onAddBill: (bill: RecurringBill) => void;
  onToggleStatus: (id: string) => void;
  onDeleteBill: (id: string) => void;
}

export const RecurringBills: React.FC<RecurringBillsProps> = ({
  bills,
  onAddBill,
  onToggleStatus,
  onDeleteBill,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [amount, setAmount] = useState('');
  const [dueDate, setDueDate] = useState('1');
  const [category, setCategory] = useState('Subscriptions');

  const totalFixedOverhead = bills.reduce((sum, b) => sum + b.amount, 0);
  const paidOverhead = bills.filter((b) => b.status === 'paid').reduce((sum, b) => sum + b.amount, 0);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !amount) return;

    onAddBill({
      id: `rb-${Date.now()}`,
      name,
      amount: parseFloat(amount),
      dueDate: parseInt(dueDate, 10),
      category,
      autoPay: true,
      status: 'pending',
    });

    setName('');
    setAmount('');
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="p-5 bg-white border border-slate-200/80 rounded-xl shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center space-x-2">
            <CalendarClock className="w-5 h-5 text-blue-600" />
            <span>Recurring Commitments & Subscriptions</span>
          </h1>
          <p className="text-xs text-slate-500">Monitor monthly fixed overhead and prevent surprise renewal charges</p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center space-x-1.5 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs shadow-blue-600/20 transition active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>New Subscription/Bill</span>
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 bg-white border border-slate-200/80 rounded-xl shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Monthly Overhead</span>
          <p className="text-2xl font-bold text-slate-900 mt-1">{formatCurrency(totalFixedOverhead)}</p>
        </div>
        <div className="p-4 bg-white border border-slate-200/80 rounded-xl shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Settled This Month</span>
          <p className="text-2xl font-bold text-emerald-600 mt-1">{formatCurrency(paidOverhead)}</p>
        </div>
        <div className="p-4 bg-white border border-slate-200/80 rounded-xl shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Pending Outflow</span>
          <p className="text-2xl font-bold text-amber-600 mt-1">{formatCurrency(totalFixedOverhead - paidOverhead)}</p>
        </div>
      </div>

      {/* Bills Table */}
      <div className="bg-white border border-slate-200/80 rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-semibold border-b border-slate-200/80">
              <tr>
                <th className="p-3.5">Bill / Provider Name</th>
                <th className="p-3.5">Category</th>
                <th className="p-3.5">Due Day</th>
                <th className="p-3.5 text-right">Monthly Charge</th>
                <th className="p-3.5 text-center">Status</th>
                <th className="p-3.5 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {bills.map((b) => (
                <tr key={b.id} className="hover:bg-slate-50/80 transition">
                  <td className="p-3.5">
                    <div className="font-semibold text-slate-900 flex items-center space-x-2">
                      <RefreshCw className="w-3.5 h-3.5 text-blue-600" />
                      <span>{b.name}</span>
                    </div>
                  </td>
                  <td className="p-3.5 text-slate-500">{b.category}</td>
                  <td className="p-3.5 text-slate-600 font-mono">Day {b.dueDate} of month</td>
                  <td className="p-3.5 text-right font-bold text-slate-900 text-sm">{formatCurrency(b.amount)}</td>
                  <td className="p-3.5 text-center">
                    <button
                      onClick={() => onToggleStatus(b.id)}
                      className={`inline-flex items-center space-x-1 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase transition ${
                        b.status === 'paid'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : 'bg-amber-50 text-amber-700 border border-amber-200'
                      }`}
                    >
                      {b.status === 'paid' ? (
                        <>
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          <span>PAID</span>
                        </>
                      ) : (
                        <>
                          <Clock className="w-3 h-3 text-amber-600" />
                          <span>PENDING</span>
                        </>
                      )}
                    </button>
                  </td>
                  <td className="p-3.5 text-center">
                    <button
                      onClick={() => onDeleteBill(b.id)}
                      className="p-1.5 rounded hover:bg-slate-100 text-slate-400 hover:text-rose-600 transition"
                      title="Delete Bill"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* New Bill Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4">
          <div className="bg-white border border-slate-200 rounded-2xl p-6 w-full max-w-md shadow-xl text-slate-900 space-y-4">
            <h2 className="text-lg font-bold text-slate-900 mb-4">Add Recurring Bill</h2>
            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Bill / Service Name</label>
                <input
                  type="text"
                  placeholder="e.g. Netflix, Gym, Electric Company"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs text-slate-800 focus:outline-none focus:border-blue-600 focus:bg-white transition"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Monthly Amount ($)</label>
                  <input
                    type="number"
                    placeholder="e.g. 29.99"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs text-slate-800 focus:outline-none focus:border-blue-600 focus:bg-white transition"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Due Day of Month</label>

                  <select
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs text-slate-800 focus:outline-none focus:border-blue-600 focus:bg-white transition"
                  >
                    {Array.from({ length: 31 }, (_, i) => (
                      <option key={i + 1} value={i + 1}>
                        Day {i + 1}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Category</label>
                <input
                  type="text"
                  placeholder="e.g. Utilities, Housing, Entertainment"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs text-slate-800 focus:outline-none focus:border-blue-600 focus:bg-white transition"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-xs"
                >
                  Save Bill
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
