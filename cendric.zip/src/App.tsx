import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Dashboard } from './components/Dashboard';
import { Transactions } from './components/Transactions';
import { Budgets } from './components/Budgets';
import { Goals } from './components/Goals';
import { RecurringBills } from './components/RecurringBills';
import { AiAdvisor } from './components/AiAdvisor';
import { AddTransactionModal } from './components/AddTransactionModal';
import {
  initialTransactions,
  initialBudgets,
  initialGoals,
  initialRecurringBills,
  initialNetWorthData,
} from './data/initialData';
import { Transaction, BudgetCategory, FinancialGoal, RecurringBill, NetWorthPoint } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // Local storage state initialization
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('cendric_transactions');
    return saved ? JSON.parse(saved) : initialTransactions;
  });

  const [budgets, setBudgets] = useState<BudgetCategory[]>(() => {
    const saved = localStorage.getItem('cendric_budgets');
    return saved ? JSON.parse(saved) : initialBudgets;
  });

  const [goals, setGoals] = useState<FinancialGoal[]>(() => {
    const saved = localStorage.getItem('cendric_goals');
    return saved ? JSON.parse(saved) : initialGoals;
  });

  const [bills, setBills] = useState<RecurringBill[]>(() => {
    const saved = localStorage.getItem('cendric_bills');
    return saved ? JSON.parse(saved) : initialRecurringBills;
  });

  const [netWorthData] = useState<NetWorthPoint[]>(initialNetWorthData);

  // Modal State
  const [isAddTxModalOpen, setIsAddTxModalOpen] = useState(false);
  const [editingTx, setEditingTx] = useState<Transaction | null>(null);

  // Sync state to local storage
  useEffect(() => {
    localStorage.setItem('cendric_transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('cendric_budgets', JSON.stringify(budgets));
  }, [budgets]);

  useEffect(() => {
    localStorage.setItem('cendric_goals', JSON.stringify(goals));
  }, [goals]);

  useEffect(() => {
    localStorage.setItem('cendric_bills', JSON.stringify(bills));
  }, [bills]);

  // Total balance calculation
  const baseBalance = 84500.0;
  const netTransactionChange = transactions.reduce((sum, t) => {
    if (t.type === 'income') return sum + t.amount;
    if (t.type === 'expense') return sum - t.amount;
    return sum; // investments stay inside portfolio
  }, 0);

  const totalBalance = baseBalance + netTransactionChange;

  // Categories list for modal autocomplete
  const categoriesList = Array.from(
    new Set([
      ...budgets.map((b) => b.name),
      'Salary',
      'Freelance',
      'Groceries',
      'Housing',
      'Investments',
      'Utilities',
      'Shopping',
      'Dining & Coffee',
      'Transportation',
    ])
  );

  // Transaction Actions
  const handleSaveTransaction = (tx: Transaction) => {
    if (editingTx) {
      setTransactions((prev) => prev.map((item) => (item.id === tx.id ? tx : item)));
    } else {
      setTransactions((prev) => [tx, ...prev]);

      // Automatically update budget spent if matching expense category
      if (tx.type === 'expense') {
        setBudgets((prev) =>
          prev.map((b) =>
            b.name.toLowerCase() === tx.category.toLowerCase()
              ? { ...b, spent: b.spent + tx.amount }
              : b
          )
        );
      }
    }
    setEditingTx(null);
  };

  const handleDeleteTransaction = (id: string) => {
    setTransactions((prev) => prev.filter((t) => t.id !== id));
  };

  const handleEditTransaction = (tx: Transaction) => {
    setEditingTx(tx);
    setIsAddTxModalOpen(true);
  };

  // Budget Actions
  const handleAddBudget = (category: BudgetCategory) => {
    setBudgets((prev) => [...prev, category]);
  };

  const handleUpdateBudget = (id: string, allocated: number) => {
    setBudgets((prev) => prev.map((b) => (b.id === id ? { ...b, allocated } : b)));
  };

  const handleDeleteBudget = (id: string) => {
    setBudgets((prev) => prev.filter((b) => b.id !== id));
  };

  // Goal Actions
  const handleAddGoal = (goal: FinancialGoal) => {
    setGoals((prev) => [...prev, goal]);
  };

  const handleUpdateGoalContribution = (id: string, newAmount: number) => {
    setGoals((prev) => prev.map((g) => (g.id === id ? { ...g, currentAmount: newAmount } : g)));
  };

  const handleDeleteGoal = (id: string) => {
    setGoals((prev) => prev.filter((g) => g.id !== id));
  };

  // Bill Actions
  const handleAddBill = (bill: RecurringBill) => {
    setBills((prev) => [...prev, bill]);
  };

  const handleToggleBillStatus = (id: string) => {
    setBills((prev) =>
      prev.map((b) =>
        b.id === id ? { ...b, status: b.status === 'paid' ? 'pending' : 'paid' } : b
      )
    );
  };

  const handleDeleteBill = (id: string) => {
    setBills((prev) => prev.filter((b) => b.id !== id));
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-800 font-sans selection:bg-blue-600 selection:text-white">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenAddTransaction={() => {
          setEditingTx(null);
          setIsAddTxModalOpen(true);
        }}
        totalBalance={totalBalance}
      />

      {/* Main View Area */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'dashboard' && (
          <Dashboard
            transactions={transactions}
            budgets={budgets}
            netWorthData={netWorthData}
            totalBalance={totalBalance}
            onOpenAddTransaction={() => {
              setEditingTx(null);
              setIsAddTxModalOpen(true);
            }}
            onNavigateTab={setActiveTab}
            onRequestAiAudit={() => setActiveTab('ai-advisor')}
          />
        )}

        {activeTab === 'transactions' && (
          <Transactions
            transactions={transactions}
            onAddTransaction={() => {
              setEditingTx(null);
              setIsAddTxModalOpen(true);
            }}
            onEditTransaction={handleEditTransaction}
            onDeleteTransaction={handleDeleteTransaction}
          />
        )}

        {activeTab === 'budgets' && (
          <Budgets
            budgets={budgets}
            onAddBudget={handleAddBudget}
            onUpdateBudget={handleUpdateBudget}
            onDeleteBudget={handleDeleteBudget}
          />
        )}

        {activeTab === 'goals' && (
          <Goals
            goals={goals}
            onAddGoal={handleAddGoal}
            onUpdateGoalContribution={handleUpdateGoalContribution}
            onDeleteGoal={handleDeleteGoal}
          />
        )}

        {activeTab === 'bills' && (
          <RecurringBills
            bills={bills}
            onAddBill={handleAddBill}
            onToggleStatus={handleToggleBillStatus}
            onDeleteBill={handleDeleteBill}
          />
        )}

        {activeTab === 'ai-advisor' && (
          <AiAdvisor
            transactions={transactions}
            budgets={budgets}
            goals={goals}
            totalBalance={totalBalance}
          />
        )}
      </main>

      {/* Add/Edit Transaction Modal */}
      <AddTransactionModal
        isOpen={isAddTxModalOpen}
        onClose={() => {
          setIsAddTxModalOpen(false);
          setEditingTx(null);
        }}
        onSave={handleSaveTransaction}
        editingTx={editingTx}
        categories={categoriesList}
      />
    </div>
  );
}
