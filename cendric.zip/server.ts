import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Health check
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', app: 'Cendric Finance Management' });
  });

  // AI Financial Advisor Endpoint
  app.post('/api/ai/financial-advisor', async (req, res) => {
    try {
      const { query, transactions = [], budgets = [], goals = [], totalBalance = 0 } = req.body;

      // Extract metrics for analysis
      const totalIncome = transactions
        .filter((t: any) => t.type === 'income')
        .reduce((sum: number, t: any) => sum + Number(t.amount), 0);

      const totalExpenses = transactions
        .filter((t: any) => t.type === 'expense')
        .reduce((sum: number, t: any) => sum + Number(t.amount), 0);

      const totalInvestments = transactions
        .filter((t: any) => t.type === 'investment')
        .reduce((sum: number, t: any) => sum + Number(t.amount), 0);

      const netSavings = totalIncome - totalExpenses;
      const savingsRate = totalIncome > 0 ? Math.max(0, Math.round((netSavings / totalIncome) * 100)) : 0;

      const apiKey = process.env.GEMINI_API_KEY;

      if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
        const ai = new GoogleGenAI({ apiKey });

        const prompt = `
You are Cendric AI, an elite, highly sophisticated, empathetic financial advisor and wealth management expert.
Analyze the user's current financial snapshot below and answer their specific query or produce a complete financial checkup.

Financial Snapshot:
- Liquid Total Balance: $${totalBalance.toLocaleString()}
- Total Monthly Income: $${totalIncome.toLocaleString()}
- Total Monthly Expenses: $${totalExpenses.toLocaleString()}
- Monthly Net Investments: $${totalInvestments.toLocaleString()}
- Current Monthly Savings Rate: ${savingsRate}%
- Active Budgets: ${JSON.stringify(budgets.map((b: any) => ({ name: b.name, allocated: b.allocated, spent: b.spent })))}
- Financial Goals: ${JSON.stringify(goals.map((g: any) => ({ title: g.title, target: g.targetAmount, current: g.currentAmount })))}

User Prompt/Query: "${query || 'Provide a thorough financial assessment, budget optimization, and wealth growth strategy.'}"

Return your response strictly in raw valid JSON format without markdown code fences. Structure:
{
  "summary": "Concise executive financial assessment paragraph",
  "healthScore": 88, // integer 0-100 based on savings rate, emergency fund, and budget control
  "savingsRate": ${savingsRate},
  "keyActionItems": [
    "Actionable financial recommendation 1",
    "Actionable financial recommendation 2",
    "Actionable financial recommendation 3"
  ],
  "budgetAlerts": [
    "Alert or observation about budget utilization or spending behavior"
  ]
}
`;

        try {
          const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
          });

          let text = response.text || '';
          text = text.replace(/```json/g, '').replace(/```/g, '').trim();
          const parsed = JSON.parse(text);
          return res.json(parsed);
        } catch (geminiError) {
          console.error('Gemini API call failed, falling back to rule engine:', geminiError);
        }
      }

      // Rule-based fallback if API key is not configured or fails
      const healthScore = Math.min(100, Math.max(40, 50 + (savingsRate * 0.8) + (totalBalance > 10000 ? 15 : 5)));
      const budgetAlerts: string[] = [];

      budgets.forEach((b: any) => {
        if (b.spent >= b.allocated) {
          budgetAlerts.push(`Alert: Category "${b.name}" has reached 100% of its $${b.allocated} allocated limit.`);
        } else if (b.spent / b.allocated > 0.85) {
          budgetAlerts.push(`Notice: Category "${b.name}" is near capacity (${Math.round((b.spent / b.allocated) * 100)}% spent).`);
        }
      });

      if (budgetAlerts.length === 0) {
        budgetAlerts.push('All budget categories are currently operating within healthy target allocations.');
      }

      const keyActionItems = [
        `Maintain your strong ${savingsRate}% savings rate by automating monthly deposits to yield-bearing accounts.`,
        `Review recurring subscriptions to unlock an extra $50-$100/mo in free cash flow.`,
        `Consider allocating any excess net income into low-cost index funds to accelerate long-term compounding.`
      ];

      return res.json({
        summary: query 
          ? `Analysis for "${query}": Your financial foundation is sound with a net monthly cash surplus of $${netSavings.toLocaleString()} and a ${savingsRate}% savings rate.`
          : `Cendric Health Audit: Your finances are in good order with a net monthly surplus of $${netSavings.toLocaleString()} and balance of $${totalBalance.toLocaleString()}.`,
        healthScore,
        savingsRate,
        keyActionItems,
        budgetAlerts,
      });

    } catch (err: any) {
      console.error('Error in /api/ai/financial-advisor:', err);
      res.status(500).json({ error: 'Failed to generate financial analysis' });
    }
  });

  // Vite development middleware or static production serving
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Cendric server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
